package com.fdmgroup.sudoku;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SudokuValidator {

	/// read file into 'grid'
	/// consider variable square number sizes
	public List<ArrayList<String>> fileReader(String filepath) {

		List<ArrayList<String>> sudokuGrid = new ArrayList<ArrayList<String>>();
		String sudokuLine;
		BufferedReader bufferedReader;

		try {
			bufferedReader = new BufferedReader(new FileReader(filepath));

			// reads until there are no more lines
			while ((sudokuLine = bufferedReader.readLine()) != null) {

				ArrayList<String> horizontalLine = new ArrayList<String>();

				for (String number : sudokuLine.split(",")) {
					horizontalLine.add(number);
				}

				sudokuGrid.add(horizontalLine);

			}

			bufferedReader.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return sudokuGrid;
	}

	/////////////////////////////
	//////////DIMENSION//////////
	////////////CHECK////////////	
	
	/// check dimensions of grid
	public boolean dimensionCheck(List<ArrayList<String>> sudokuGrid) {
		
		boolean valid = true;
		ArrayList<Integer> longLines = new ArrayList<Integer>();
		ArrayList<Integer> shortLines = new ArrayList<Integer>();
		
		int numberOfLines = sudokuGrid.size();
		
		if (numberOfLines < 9) {// first check for correct number of rows
			System.out.println("Invalid puzzle. Too few lines in file");
			valid = false;//INVALID too few lines
		} else if (numberOfLines > 9) {// first check for correct number of rows
			System.out.println("Invalid puzzle. Too many lines in file");
			valid = false;//INVALID too many lines
		} else {
			//// need to check all lines without
			//// breaking
			for (int lineNumber = 0; lineNumber < numberOfLines; lineNumber++) {
				ArrayList<String> row = sudokuGrid.get(lineNumber);
				if (row.size() < 9) {
					shortLines.add(lineNumber);
					valid = false;
				}else if (row.size() > 9) {
					longLines.add(lineNumber);
					valid = false;
				}
			}
			
			if(!shortLines.isEmpty()){
				System.out.println("Invalid puzzle. Too few entries on line(s) "+ shortLines);
			}
			if(!longLines.isEmpty()){
				System.out.println("Invalid puzzle. Too many entries on line(s) "+ longLines);
			}
		}
		return valid;
	}

	
	/////////////////////////////
	///////////CONTENT///////////
	////////////CHECK////////////	
	
	/// setup control list
	public ArrayList<String> controlList() {

		// Create control arrayList to compare grid contents to
		String[] control = { "1", "2", "3", "4", "5", "6", "7", "8", "9" };
		ArrayList<String> allNumbers = new ArrayList<String>();
		for (int i = 0; i < control.length; i++) {
			allNumbers.add(control[i]);
		}

		return allNumbers;
	}

	/// check rows
	public boolean horizontalCheck(List<ArrayList<String>> sudokuGrid) {

		SudokuValidator validator = new SudokuValidator();
		ArrayList<String> allNumbers = validator.controlList();
		boolean valid = true;
		ArrayList<Integer> invalidRows = new ArrayList<Integer>();

		for (int lineNumber = 0; lineNumber < sudokuGrid.size(); lineNumber++) {
			ArrayList<String> row = sudokuGrid.get(lineNumber);
			if (!row.containsAll(allNumbers)) {
				invalidRows.add(lineNumber);
				valid = false;//INVALID row doesn't contain all numbers
			}
		}
		if(!invalidRows.isEmpty()){
			System.out.println("Invalid puzzle. Not all required numbers are present on line(s) "+invalidRows);
		}
		
		return valid;//VALID numbers present

	}

	/// check columns
	public boolean verticalCheck(List<ArrayList<String>> sudokuGrid) {

		SudokuValidator validator = new SudokuValidator();
		ArrayList<String> allNumbers = validator.controlList();
		boolean valid = true;
		ArrayList<Integer> invalidColumns = new ArrayList<Integer>();

		int gridSize = sudokuGrid.get(0).size();
//		while(sudokuGrid.get(0).get(columnNumber) != null)
		
		for (int columnNumber = 0; columnNumber < gridSize; columnNumber++) {
			ArrayList<String> column = new ArrayList<String>();
			for (int lineNumber = 0; lineNumber < sudokuGrid.size(); lineNumber++) {
				ArrayList<String> row = sudokuGrid.get(lineNumber);
				column.add(row.get(columnNumber));
			}
			if (!column.containsAll(allNumbers)) {/// check column
				invalidColumns.add(columnNumber);
				
				valid = false;//INVALID column doesn't contain all numbers //// consider putting column number
			}
		}
		if(!invalidColumns.isEmpty()){
			System.out.println("Invalid puzzle. Not all required numbers are present on column(s) "+invalidColumns);
		}
		
		return valid;//VALID numbers present

	}

	// check boxes
	public boolean boxCheck(List<ArrayList<String>> sudokuGrid) {

		// setup control ArrayList to compare result to
		SudokuValidator validator = new SudokuValidator();
		ArrayList<String> allNumbers = validator.controlList();

		// loop through grid considering sets of 3 lines
		for (int boxLine = 0; boxLine < 9; boxLine += 3) {// these two for loops
															// should control
															// which grid square
															// we consider
			ArrayList<String> box;

			for (int boxColumn = 0; boxColumn < 9; boxColumn += 3) {// loop
																	// columns
																	// in grid
				box = new ArrayList<String>();// setup an Array each time a new
												// box is considered

				for (int lineNumber = boxLine; lineNumber < boxLine + 3; lineNumber++) {// loop
																						// the
																						// 3
																						// lines
																						// in
																						// the
																						// grid
					ArrayList<String> line = sudokuGrid.get(lineNumber);// get
																		// each
																		// ArrayList
																		// 'line'

					for (int columnNumber = boxColumn; columnNumber < boxColumn + 3; columnNumber++) {// in
																										// each
																										// list,
																										// loop
																										// through
																										// column
																										// width

						String s = line.get(columnNumber);// get the String at
															// (i)(j) then add
															// to current box
															// List
						box.add(s);

						if (columnNumber == 0 && lineNumber == 0) {// at initial
																	// position
																	// avoid
																	// returning
																	// false by
																	// creating
																	// a new
																	// ArrayList
																	// object
							// empty for now to avoid next clause

						} else if ((columnNumber + 1) % 3 == 0 && (lineNumber + 1) % 3 == 0) {// every
																								// 3
																								// lines
																								// check
																								// contents
																								// of
																								// box
																								// then
																								// empty

							if (!box.containsAll(allNumbers)) {// check box
																// doesn't
																// contain list
																// of numbers we
																// require
								System.out.println("Invalid puzzle. One or more boxes doesn't contain all required numbers");
								return false;// if all numbers aren't present
												// then puzzle INVALID box doesn't contain all numbers
							}
						}
					}
				}
			}
		}
		System.out.println("Valid puzzle solution");
		return true;//VALID numbers present
	}

}
