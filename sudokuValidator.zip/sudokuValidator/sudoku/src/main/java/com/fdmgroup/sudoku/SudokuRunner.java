package com.fdmgroup.sudoku;

import java.util.ArrayList;
import java.util.List;

public class SudokuRunner {

	public static void main(String[] args) {
		SudokuValidator sudoku = new SudokuValidator();
		List<ArrayList<String>> sudokuGrid = sudoku.fileReader(args[0]);
		if(sudoku.dimensionCheck(sudokuGrid) == false){
			System.exit(1);
		}
		sudoku.horizontalCheck(sudokuGrid);
		sudoku.verticalCheck(sudokuGrid);
		sudoku.boxCheck(sudokuGrid);
		
		
		
		
		
		
		//System.exit
		
		///needs to print valid and invalid message

	}

}
