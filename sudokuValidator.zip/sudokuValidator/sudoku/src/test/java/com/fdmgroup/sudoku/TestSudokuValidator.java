package com.fdmgroup.sudoku;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class TestSudokuValidator {

	BufferedReader bufferedReader;
	SudokuValidator validator = null;
	String filePath="src\\main\\resources\\puzzleName.txt";
	String sudokuControl= "src\\main\\resources\\sudokuControl.txt";
	ArrayList<String> comparison= new ArrayList<String>();

	@Before
	public void setup() throws Exception {
		// set something up here maybe
		validator = new SudokuValidator();
		comparison.clear();
		comparison.add("1");
		comparison.add("2");
		comparison.add("3");
		comparison.add("4");
		comparison.add("5");
		comparison.add("6");
		comparison.add("7");
		comparison.add("8");
		comparison.add("9");

	}

	// check file read in
	@Test
	public void test_fileIsReadIn() {
		List<ArrayList<String>> output = validator.fileReader("src\\main\\resources\\testFile.txt");
		assertNotNull(output);
	}

	// check correct info is read in
	@Test
	public void test_whenFileIsReadItReturnsCorrectInformation() {
		List<ArrayList<String>> output = validator.fileReader("src\\main\\resources\\testFile.txt");
		ArrayList<String> firstString = output.get(0);
		assertEquals("test", firstString.get(0));
	}

	@Test
	public void test_whenFileIsReadItReturnsCorrectInformationSecondColumn() {
		List<ArrayList<String>> output = validator.fileReader("src\\main\\resources\\testFile.txt");
		ArrayList<String> firstString = output.get(0);
		assertEquals("read", firstString.get(1));
	}

	// test the whole file is read in, correct number of lines
	@Test
	public void test_readingSudokuLinesReadsCorrectNumberOfLines() {
		List<ArrayList<String>> output = validator.fileReader(filePath);
		int fileLines = output.size();
		assertEquals(9, fileLines);
	}

	// check correct number of entries per line
	@Test
	public void test_readingSudokuLinesReadsCorrectNumberEntriesPerLine() {
		List<ArrayList<String>> output = validator.fileReader(filePath);
		ArrayList<String> firstString = output.get(0);
		int lineEntries = firstString.size();
		assertEquals(9, lineEntries);
	}

	// check correct number of entries on last line
	@Test
	public void test_readingSudokuLinesReadsCorrectNumberEntriesInLastLine() {
		List<ArrayList<String>> output = validator.fileReader(filePath);
		ArrayList<String> firstString = output.get(8);
		int lineEntries = firstString.size();
		assertEquals(9, lineEntries);
	}

	// check correct information
	@Test
	public void test_readingSudokuLinesReturnsCorrectInformation() {
		List<ArrayList<String>> output = validator.fileReader(filePath);
		ArrayList<String> firstString = output.get(5);

		assertTrue(firstString.containsAll(comparison));
	}

	// check validation
	// too many lines
	@Test
	public void test_dimensionValidatorReturnsFalseWhenTooLongAFileIsRead() {
		List<ArrayList<String>> output = validator.fileReader("src\\main\\resources\\puzzleLong.txt");
		assertFalse(validator.dimensionCheck(output));

	}

	// too few lines
	@Test
	public void test_dimensionValidatorReturnsFalseWhenTooShortAFileIsRead() {
		List<ArrayList<String>> output = validator.fileReader("src\\main\\resources\\puzzleShort.txt");
		assertFalse(validator.dimensionCheck(output));

	}

	// control
	@Test
	public void test_dimensionValidatorReturnsTrueWhenControlFileIsRead() {
		List<ArrayList<String>> output = validator.fileReader(filePath);
		assertTrue(validator.dimensionCheck(output));

	}

	// lines too long
	@Test
	public void test_dimensionValidatorReturnsFalseWhenLinesAreTooLong() {
		List<ArrayList<String>> output = validator.fileReader("src\\main\\resources\\puzzleLongLine.txt");
		assertFalse(validator.dimensionCheck(output));

	}

	// lines too short
	@Test
	public void test_dimensionValidatorReturnsFalseWhenLinesAreTooShort() {
		List<ArrayList<String>> output = validator.fileReader("src\\main\\resources\\puzzleShortLine.txt");
		assertFalse(validator.dimensionCheck(output));

	}

	/// check content
	// check a whole line
	@Test
	public void test_validatingRowsReturnsTrueWhenControlSudokuIsReadIn() {
		List<ArrayList<String>> output = validator.fileReader(sudokuControl);
		assertTrue(validator.horizontalCheck(output));
	}
	// check a whole line wrong
	@Test
	public void test_validatingRowsReturnsFalseWhenIncorrectSudokuIsReadIn() {
		List<ArrayList<String>> output = validator.fileReader("src\\main\\resources\\sudokuAllOnes.txt");
		assertFalse(validator.horizontalCheck(output));
	}
	
	// check a column
	@Test
	public void test_validatingcolumnsReturnsTrueWhenControlSudokuIsReadIn() {
		List<ArrayList<String>> output = validator.fileReader(sudokuControl);
		assertTrue(validator.verticalCheck(output));
	}
	// check a column incorrect
	@Test
	public void test_validatingcolumnsReturnsFalseWhenIncorrectSudokuIsReadIn() {
		List<ArrayList<String>> output = validator.fileReader("src\\main\\resources\\sudokuAllOnes.txt");
		assertFalse(validator.verticalCheck(output));
	}
	
	@Test
	public void test_validatingcolumnsReturnsFalseWhenPuzzleExampleIsReadIn() {
		List<ArrayList<String>> output = validator.fileReader(filePath);
		assertFalse(validator.verticalCheck(output));
	}
	
	
	//check boxes
	@Test
	public void test_validatingBoxesReturnsFalseWhenPuzzleExampleIsReadIn(){
		List<ArrayList<String>> output = validator.fileReader(filePath);
		assertFalse(validator.boxCheck(output));
		
	}
	
	@Test
	public void test_validatingBoxesReturnsTrueWhenControlSudokuIsReadIn(){
		List<ArrayList<String>> output = validator.fileReader(sudokuControl);
		assertTrue(validator.boxCheck(output));
		
	}
	
	@Test
	public void test_validatingBoxesReturnsTrueWhenForiegnSudokuIsReadIn(){
		List<ArrayList<String>> output = validator.fileReader("src\\main\\resources\\sudokuFound.txt");
		assertTrue(validator.boxCheck(output));
	}
	
	@Test
	public void test_validatingLinesReturnsFalseWhenPuzzleWithOneErrorIsReadIn(){
		List<ArrayList<String>> output = validator.fileReader("src\\main\\resources\\sudokuOneError.txt");
		assertFalse(validator.horizontalCheck(output));
	}
	
	@Test
	public void test_validatingColumnsReturnsFalseWhenPuzzleWithOneErrorIsReadIn(){
		List<ArrayList<String>> output = validator.fileReader("src\\main\\resources\\sudokuOneError.txt");
		assertFalse(validator.verticalCheck(output));
	}
	
	
	

	
	
	
	
}
